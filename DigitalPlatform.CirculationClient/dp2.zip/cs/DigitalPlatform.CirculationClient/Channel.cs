using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.Diagnostics;
using System.Threading;
using System.Windows.Forms;

using DigitalPlatform;
using DigitalPlatform.CirculationClient.localhost;

namespace DigitalPlatform.CirculationClient
{
    public delegate void BeforeLoginEventHandle(object sender,
    BeforeLoginEventArgs e);

    public class BeforeLoginEventArgs : EventArgs
    {
        public bool FirstTry = true;
        public string CirculationServerUrl = "";
        public string UserName = "";
        public string Password = "";
        public string Location = "";
        public bool IsReader = false;
        public bool SavePassword = false;
        public bool Failed = false;
        public bool Cancel = false;
        public string ErrorInfo = "";
    }

    public class Channel
    {
        public string Url = "";

        localhost.CirculationWse m_ws = null;	// ӵ��

        public string UserName = "";
        public string Password = "";

        public CookieContainer Cookies = new System.Net.CookieContainer();

        public event BeforeLoginEventHandle BeforeLogin;

        object resultParam = null;
        AutoResetEvent eventComplete = new AutoResetEvent(false);

        public ErrorCode ErrorCode = ErrorCode.NoError;

        public localhost.CirculationWse ws
        {
            get
            {
                if (m_ws == null)
                {
                    m_ws = new localhost.CirculationWse();
                }

                Debug.Assert(this.Url != "", "Urlֵ��ʱӦ�������ڿ�");

                m_ws.Url = this.Url;
                m_ws.CookieContainer = this.Cookies;

                return m_ws;
            }
        }


        public long Login(string strUserName,
            string strPassword,
            string strLocation,
            bool bReader,
            out string strError)
        {
            strError = "";

            Result result = ws.Login(strUserName,
                strPassword,
                strLocation,
                bReader);

            strError = result.ErrorInfo;
            return result.Value;
        }

        // ����������Ϣ
        public long SearchReader(
            DigitalPlatform.Stop stop,
            string strQueryWord,
            string strFrom,
            string strMatchStyle,
            string strLang,
            string strResultSetName,
            out string strError)
        {
            strError = "";

            REDO:
            ws.SearchReaderCompleted += new SearchReaderCompletedEventHandler(ws_SearchReaderCompleted);

            try
            {

                this.eventComplete.Reset();
                ws.SearchReaderAsync(strQueryWord,
                    strFrom,
                    strMatchStyle,
                    strLang,
                    strResultSetName);

                while (true)
                {
                    Application.DoEvents();	// ���ý������Ȩ

                    if (stop != null)
                    {
                        if (stop.State != 0)
                        {
                            strError = "�û��ж�1";
                            return -1;
                        }
                    }

                    bool bRet = this.eventComplete.WaitOne(10, true);
                    if (bRet == true)
                        break;
                }

            }
            finally
            {
                ws.SearchReaderCompleted -= new SearchReaderCompletedEventHandler(ws_SearchReaderCompleted);
            }

            SearchReaderCompletedEventArgs e = (SearchReaderCompletedEventArgs)this.resultParam;

            if (e.Error != null)
            {
                strError = e.Error.Message;
                return -1;
            }

            if (e.Cancelled == true)
                strError = "�û��ж�2";
            else
                strError = e.Result.ErrorInfo;

            if (e.Result.Value == -1 && e.Result.ErrorCode == ErrorCode.NotLogin)
            {
                if (DoNotLogin(ref strError) == 1)
                    goto REDO;
            }

            this.ErrorCode = e.Result.ErrorCode;
            return e.Result.Value;
        }

        void ws_SearchReaderCompleted(object sender, SearchReaderCompletedEventArgs e)
        {
            /*
            string strText = "Canceled = "
            + e.Cancelled.ToString();
            + " ErrorInfo = " +  e.Result.ErrorInfo;
             */

            this.resultParam = e;
            this.eventComplete.Set();
        }

        // ����������Ϣ
        public long SearchItem(
            DigitalPlatform.Stop stop,
            string strQueryWord,
            string strFrom,
            string strMatchStyle,
            string strLang,
            string strResultSetName,
            out string strError)
        {
            strError = "";

            REDO:
            ws.SearchItemCompleted += new SearchItemCompletedEventHandler(ws_SearchItemCompleted);

            try
            {

                this.eventComplete.Reset();
                ws.SearchItemAsync(strQueryWord,
                    strFrom,
                    strMatchStyle,
                    strLang,
                    strResultSetName);

                while (true)
                {
                    Application.DoEvents();	// ���ý������Ȩ

                    if (stop != null)
                    {
                        if (stop.State != 0)
                        {
                            strError = "�û��ж�1";
                            return -1;
                        }
                    }

                    bool bRet = this.eventComplete.WaitOne(10, true);
                    if (bRet == true)
                        break;
                }

            }
            finally
            {
                ws.SearchItemCompleted -= new SearchItemCompletedEventHandler(ws_SearchItemCompleted);
            }

            SearchItemCompletedEventArgs e = (SearchItemCompletedEventArgs)this.resultParam;

            if (e.Error != null)
            {
                strError = e.Error.Message;
                return -1;
            }

            if (e.Cancelled == true)
                strError = "�û��ж�2";
            else
                strError = e.Result.ErrorInfo;

            if (e.Result.Value == -1 && e.Result.ErrorCode == ErrorCode.NotLogin)
            {
                if (DoNotLogin(ref strError) == 1)
                    goto REDO;
            }

            this.ErrorCode = e.Result.ErrorCode;
            return e.Result.Value;
        }

        void ws_SearchItemCompleted(object sender, SearchItemCompletedEventArgs e)
        {
            this.resultParam = e;
            this.eventComplete.Set();
        }

        // ��ü������
        public long GetSearchResult(
            DigitalPlatform.Stop stop,
            string strResultSetName,
            long lStart,
            long lCount,
            string strBrowseInfoStyle,
            string strLang,
            out SearchResult[] searchresults,
            out string strError)
        {
            searchresults = null;
            strError = "";

            REDO:
            ws.GetSearchResultCompleted += new GetSearchResultCompletedEventHandler(ws_GetSearchResultCompleted);

            try
            {

                this.eventComplete.Reset();
                ws.GetSearchResultAsync(
                    strResultSetName,
                    lStart,
                    lCount,
                    strBrowseInfoStyle,
                    strLang);

                while (true)
                {
                    Application.DoEvents();	// ���ý������Ȩ

                    if (stop != null)
                    {
                        if (stop.State != 0)
                        {
                            strError = "�û��ж�1";
                            return -1;
                        }
                    }

                    bool bRet = this.eventComplete.WaitOne(10, true);
                    if (bRet == true)
                        break;
                }

            }
            finally
            {
                ws.GetSearchResultCompleted -= new GetSearchResultCompletedEventHandler(ws_GetSearchResultCompleted);
            }

            GetSearchResultCompletedEventArgs e = (GetSearchResultCompletedEventArgs)this.resultParam;

            if (e.Error != null)
            {
                strError = e.Error.Message;
                return -1;
            }

            if (e.Cancelled == true)
                strError = "�û��ж�2";
            else
                strError = e.Result.ErrorInfo;

            searchresults = e.searchresults;

            if (e.Result.Value == -1 && e.Result.ErrorCode == ErrorCode.NotLogin)
            {
                if (DoNotLogin(ref strError) == 1)
                    goto REDO;
            }

            this.ErrorCode = e.Result.ErrorCode;
            return e.Result.Value;
        }

        void ws_GetSearchResultCompleted(object sender, GetSearchResultCompletedEventArgs e)
        {
            this.resultParam = e;
            this.eventComplete.Set();
        }

        // ������ݿ��¼
        public long GetRecord(
            DigitalPlatform.Stop stop,
            string strPath,
            out byte[] timestamp,
            out string strXml,
            out string strError)
        {
            timestamp = null;
            strXml = "";
            strError = "";

            REDO:
            ws.GetRecordCompleted += new GetRecordCompletedEventHandler(ws_GetRecordCompleted);

            try
            {
                this.eventComplete.Reset();
                ws.GetRecordAsync(strPath);

                while (true)
                {
                    Application.DoEvents();	// ���ý������Ȩ

                    if (stop != null)
                    {
                        if (stop.State != 0)
                        {
                            strError = "�û��ж�1";
                            return -1;
                        }
                    }

                    bool bRet = this.eventComplete.WaitOne(10, true);
                    if (bRet == true)
                        break;
                }

            }
            finally
            {
                ws.GetRecordCompleted -= new GetRecordCompletedEventHandler(ws_GetRecordCompleted);
            }

            GetRecordCompletedEventArgs e = (GetRecordCompletedEventArgs)this.resultParam;

            if (e.Error != null)
            {
                strError = e.Error.Message;
                return -1;
            }

            if (e.Cancelled == true)
                strError = "�û��ж�2";
            else
                strError = e.Result.ErrorInfo;

            timestamp = e.timestamp;
            strXml = e.strXml;

            if (e.Result.Value == -1 && e.Result.ErrorCode == ErrorCode.NotLogin)
            {
                if (DoNotLogin(ref strError) == 1)
                    goto REDO;
            }

            this.ErrorCode = e.Result.ErrorCode;
            return e.Result.Value;
        }

        void ws_GetRecordCompleted(object sender, GetRecordCompletedEventArgs e)
        {
            this.resultParam = e;
            this.eventComplete.Set();
        }

        // ������߼�¼
        public long SetReaderInfo(
            DigitalPlatform.Stop stop,
            string strBarcode,
            string strXml,
            out string strError)
        {
            strError = "";

            REDO:
            ws.SetReaderInfoCompleted += new SetReaderInfoCompletedEventHandler(ws_SetReaderInfoCompleted);

            try
            {
                this.eventComplete.Reset();
                ws.SetReaderInfoAsync(strBarcode, strXml);

                while (true)
                {
                    Application.DoEvents();	// ���ý������Ȩ

                    if (stop != null)
                    {
                        if (stop.State != 0)
                        {
                            strError = "�û��ж�1";
                            return -1;
                        }
                    }

                    bool bRet = this.eventComplete.WaitOne(10, true);
                    if (bRet == true)
                        break;
                }

            }
            finally
            {
                ws.SetReaderInfoCompleted -= new SetReaderInfoCompletedEventHandler(ws_SetReaderInfoCompleted);
            }

            SetReaderInfoCompletedEventArgs e = (SetReaderInfoCompletedEventArgs)this.resultParam;

            if (e.Error != null)
            {
                strError = e.Error.Message;
                return -1;
            }

            if (e.Cancelled == true)
                strError = "�û��ж�2";
            else
                strError = e.Result.ErrorInfo;

            if (e.Result.Value == -1 && e.Result.ErrorCode == ErrorCode.NotLogin)
            {
                if (DoNotLogin(ref strError) == 1)
                    goto REDO;
            }

            this.ErrorCode = e.Result.ErrorCode;
            return e.Result.Value;
        }

        void ws_SetReaderInfoCompleted(object sender, SetReaderInfoCompletedEventArgs e)
        {
            this.resultParam = e;
            this.eventComplete.Set();
        }

        // ��ö��߼�¼
        public long GetReaderInfo(
            DigitalPlatform.Stop stop,
            string strBarcode,
            string strResultType,
            out string strResult,
            out string strError)
        {
            strResult = "";
            strError = "";

            REDO:

            ws.GetReaderInfoCompleted += new GetReaderInfoCompletedEventHandler(ws_GetReaderInfoCompleted);

            try
            {
                this.eventComplete.Reset();
                ws.GetReaderInfoAsync(strBarcode, strResultType);

                while (true)
                {
                    Application.DoEvents();	// ���ý������Ȩ

                    if (stop != null)
                    {
                        if (stop.State != 0)
                        {
                            strError = "�û��ж�1";
                            return -1;
                        }
                    }

                    bool bRet = this.eventComplete.WaitOne(10, true);
                    if (bRet == true)
                        break;
                }

            }
            finally
            {
                ws.GetReaderInfoCompleted -= new GetReaderInfoCompletedEventHandler(ws_GetReaderInfoCompleted);
            }

            GetReaderInfoCompletedEventArgs e = (GetReaderInfoCompletedEventArgs)this.resultParam;

            if (e.Error != null)
            {
                strError = e.Error.Message;
                return -1;
            }

            if (e.Cancelled == true)
                strError = "�û��ж�2";
            else
                strError = e.Result.ErrorInfo;

            if (e.Result.Value == -1 && e.Result.ErrorCode == ErrorCode.NotLogin)
            {
                if (DoNotLogin(ref strError) == 1)
                    goto REDO;

                /*
                if (this.BeforeLogin != null)
                {
                    BeforeLoginEventArgs ea = new BeforeLoginEventArgs();
                    ea.CirculationServerUrl = this.Url;
                REDOLOGIN:
                    this.BeforeLogin(this, ea);

                    if (ea.Cancel == true)
                    {
                        strError = "�û�������¼";
                        return -1;
                    }

                    if (ea.Failed == true)
                    {
                        strError = ea.ErrorInfo;
                        return -1;
                    }

                    long lRet = this.Login(ea.UserName,
                        ea.Password,
                        out strError);
                    if (lRet == -1 || lRet == 0)
                    {
                        ea.ErrorInfo = strError;
                        goto REDOLOGIN;
                    }

                    goto REDO;
                }
                 */
            }

            strResult = e.strResult;

            this.ErrorCode = e.Result.ErrorCode;
            return e.Result.Value;
        }

        void ws_GetReaderInfoCompleted(object sender, GetReaderInfoCompletedEventArgs e)
        {
            this.resultParam = e;
            this.eventComplete.Set();
        }

        // ������¼����
        int DoNotLogin(ref string strError)
        {
            if (this.BeforeLogin != null)
            {
                BeforeLoginEventArgs ea = new BeforeLoginEventArgs();
                ea.CirculationServerUrl = this.Url;
                ea.FirstTry = true;
            REDOLOGIN:
                this.BeforeLogin(this, ea);

                if (ea.Cancel == true)
                {
                    strError = "�û�������¼";
                    return -1;
                }

                if (ea.Failed == true)
                {
                    strError = ea.ErrorInfo;
                    return -1;
                }

                long lRet = this.Login(ea.UserName,
                    ea.Password,
                    ea.Location,
                    ea.IsReader,
                    out strError);
                if (lRet == -1 || lRet == 0)
                {
                    ea.ErrorInfo = strError;
                    ea.FirstTry = false;
                    goto REDOLOGIN;
                }

                return 1;   // ��¼�ɹ�,��������API������
            }

            return -1;
        }

        // ���ʵ���¼(��װ�汾��ʡ��3���������)
        public long GetItemInfo(
            DigitalPlatform.Stop stop,
            string strBarcode,
            string strResultType,
            out string strResult,
            string strBiblioType,
            out string strBiblio,
            out string strError)
        {
            string strItemRecPath = "";
            string strBiblioRecPath = "";
            byte[] item_timestamp = null;

            return GetItemInfo(
                stop,
                strBarcode,
                strResultType,
                out strResult,
                out strItemRecPath,
                out item_timestamp,
                strBiblioType,
                out strBiblio,
                out strBiblioRecPath,
                out strError);
        }

        // ���ʵ���¼
        public long GetItemInfo(
            DigitalPlatform.Stop stop,
            string strBarcode,
            string strResultType,
            out string strResult,
            out string strItemRecPath,
            out byte [] item_timestamp,
            string strBiblioType,
            out string strBiblio,
            out string strBiblioRecPath,
            out string strError)
        {
            strResult = "";
            strBiblio = "";
            strError = "";

            strBiblioRecPath = "";
            strItemRecPath = "";

            item_timestamp = null;


            REDO:
            ws.GetItemInfoCompleted += new GetItemInfoCompletedEventHandler(ws_GetItemInfoCompleted);

            try
            {
                this.eventComplete.Reset();
                ws.GetItemInfoAsync(strBarcode, strResultType,
                    strBiblioType);

                while (true)
                {
                    Application.DoEvents();	// ���ý������Ȩ

                    if (stop != null)
                    {
                        if (stop.State != 0)
                        {
                            strError = "�û��ж�1";
                            return -1;
                        }
                    }

                    bool bRet = this.eventComplete.WaitOne(10, true);
                    if (bRet == true)
                        break;
                }

            }
            finally
            {
                ws.GetItemInfoCompleted -= new GetItemInfoCompletedEventHandler(ws_GetItemInfoCompleted);
            }

            GetItemInfoCompletedEventArgs e = (GetItemInfoCompletedEventArgs)this.resultParam;

            if (e.Error != null)
            {
                strError = e.Error.Message;
                return -1;
            }

            if (e.Cancelled == true)
                strError = "�û��ж�2";
            else
                strError = e.Result.ErrorInfo;

            strResult = e.strResult;
            strBiblio = e.strBiblio;

            strItemRecPath = e.strItemRecPath;
            strBiblioRecPath = e.strBiblioRecPath;

            item_timestamp = e.item_timestamp;

            if (e.Result.Value == -1 && e.Result.ErrorCode == ErrorCode.NotLogin)
            {
                if (DoNotLogin(ref strError) == 1)
                    goto REDO;
            }

            this.ErrorCode = e.Result.ErrorCode;
            return e.Result.Value;
        }

        void ws_GetItemInfoCompleted(object sender, GetItemInfoCompletedEventArgs e)
        {
            this.resultParam = e;
            this.eventComplete.Set();
        }

        // ����
        public long Borrow(
            DigitalPlatform.Stop stop,
            bool bRenew,
            string strReaderBarcode,
            string strItemBarcode,
            bool bForce,
            string [] saBorrowedItemBarcode,
            string strStyle,
            string strReaderFormat,
            out string strReaderRecord,
            string strItemFormat,
            out string strItemRecord,
            out string strError)
        {
            strReaderRecord = "";
            strItemRecord = "";
            strError = "";

            REDO:
            ws.BorrowCompleted += new BorrowCompletedEventHandler(ws_BorrowCompleted);

            try
            {
                this.eventComplete.Reset();
                ws.BorrowAsync(
                    bRenew,
                    strReaderBarcode,
                    strItemBarcode,
                    bForce,
                    saBorrowedItemBarcode,
                    strStyle,
                    strItemFormat,
                    strReaderFormat);

                while (true)
                {
                    Application.DoEvents();	// ���ý������Ȩ

                    if (stop != null)
                    {
                        if (stop.State != 0)
                        {
                            strError = "�û��ж�1";
                            return -1;
                        }
                    }

                    bool bRet = this.eventComplete.WaitOne(10, true);
                    if (bRet == true)
                        break;
                }

            }
            finally
            {
                ws.BorrowCompleted -= new BorrowCompletedEventHandler(ws_BorrowCompleted);
            }

            BorrowCompletedEventArgs e = (BorrowCompletedEventArgs)this.resultParam;

            if (e.Error != null)
            {
                strError = e.Error.Message;
                return -1;
            }

            if (e.Cancelled == true)
                strError = "�û��ж�2";
            else
                strError = e.Result.ErrorInfo;

            strReaderRecord = e.strReaderRecord;
            strItemRecord = e.strItemRecord;

            if (e.Result.Value == -1 && e.Result.ErrorCode == ErrorCode.NotLogin)
            {
                if (DoNotLogin(ref strError) == 1)
                    goto REDO;
            }

            this.ErrorCode = e.Result.ErrorCode;
            return e.Result.Value;
        }

        void ws_BorrowCompleted(object sender, BorrowCompletedEventArgs e)
        {
            this.resultParam = e;
            this.eventComplete.Set();
        }

        // ����
        // return:
        //      -1  ����
        //      0   ����
        //      1   �г������
        public long Return(
            DigitalPlatform.Stop stop,
            string strReaderBarcode,
            string strItemBarcode,
            bool bForce,
            string strStyle,
            string strReaderFormat,
            out string strReaderRecord,
            out string strError)
        {
            strReaderRecord = "";
            strError = "";

            REDO:
            ws.ReturnCompleted += new ReturnCompletedEventHandler(ws_ReturnCompleted);

            try
            {
                this.eventComplete.Reset();
                ws.ReturnAsync(strReaderBarcode,
                    strItemBarcode,
                    bForce,
                    strStyle,
                    strReaderFormat,
                    bForce);

                while (true)
                {
                    Application.DoEvents();	// ���ý������Ȩ

                    if (stop != null)
                    {
                        if (stop.State != 0)
                        {
                            strError = "�û��ж�1";
                            return -1;
                        }
                    }

                    bool bRet = this.eventComplete.WaitOne(10, true);
                    if (bRet == true)
                        break;
                }

            }
            finally
            {
                ws.ReturnCompleted -= new ReturnCompletedEventHandler(ws_ReturnCompleted);
            }

            ReturnCompletedEventArgs e = (ReturnCompletedEventArgs)this.resultParam;

            if (e.Error != null)
            {
                strError = e.Error.Message;
                return -1;
            }

            if (e.Cancelled == true)
                strError = "�û��ж�2";
            else
                strError = e.Result.ErrorInfo;

            strReaderRecord = e.strReaderRecord;

            if (e.Result.Value == -1 && e.Result.ErrorCode == ErrorCode.NotLogin)
            {
                if (DoNotLogin(ref strError) == 1)
                    goto REDO;
            }

            this.ErrorCode = e.Result.ErrorCode;
            return e.Result.Value;
        }

        void ws_ReturnCompleted(object sender, ReturnCompletedEventArgs e)
        {
            this.resultParam = e;
            this.eventComplete.Set();
        }


        // // //

        // ������
        // return:
        //      -1  ����
        //      0   ����
        public long Amerce(
            DigitalPlatform.Stop stop,
            string strFunction,
            string strReaderBarcode,
            string strAmerceItemIdList,
            out string strReaderXml,
            out string strError)
        {
            strReaderXml = "";
            strError = "";

        REDO:
            ws.AmerceCompleted += new AmerceCompletedEventHandler(ws_AmerceCompleted);

            try
            {
                this.eventComplete.Reset();
                ws.AmerceAsync(strFunction,
                    strReaderBarcode,
                    strAmerceItemIdList);

                while (true)
                {
                    Application.DoEvents();	// ���ý������Ȩ

                    if (stop != null)
                    {
                        if (stop.State != 0)
                        {
                            strError = "�û��ж�1";
                            return -1;
                        }
                    }

                    bool bRet = this.eventComplete.WaitOne(10, true);
                    if (bRet == true)
                        break;
                }

            }
            finally
            {
                ws.AmerceCompleted -= new AmerceCompletedEventHandler(ws_AmerceCompleted);
            }

            AmerceCompletedEventArgs e = (AmerceCompletedEventArgs)this.resultParam;

            if (e.Error != null)
            {
                strError = e.Error.Message;
                return -1;
            }

            if (e.Cancelled == true)
                strError = "�û��ж�2";
            else
                strError = e.Result.ErrorInfo;

            strReaderXml = e.strReaderXml;

            if (e.Result.Value == -1 && e.Result.ErrorCode == ErrorCode.NotLogin)
            {
                if (DoNotLogin(ref strError) == 1)
                    goto REDO;
            }

            this.ErrorCode = e.Result.ErrorCode;
            return e.Result.Value;
        }

        void ws_AmerceCompleted(object sender, AmerceCompletedEventArgs e)
        {
            this.resultParam = e;
            this.eventComplete.Set();
        }

        //

        // ���ʵ����Ϣ
        // return:
        //      -1  ����
        //      0   ����
        public long GetEntities(
            DigitalPlatform.Stop stop,
            string strBiblioRecPath,
            out EntityInfo[] entityinfos,
            out string strError)
        {
            entityinfos = null;
            strError = "";

        REDO:
            ws.GetEntitiesCompleted +=new GetEntitiesCompletedEventHandler(ws_GetEntitiesCompleted);

            try
            {
                this.eventComplete.Reset();
                ws.GetEntitiesAsync(strBiblioRecPath);

                while (true)
                {
                    Application.DoEvents();	// ���ý������Ȩ

                    if (stop != null)
                    {
                        if (stop.State != 0)
                        {
                            strError = "�û��ж�1";
                            return -1;
                        }
                    }

                    bool bRet = this.eventComplete.WaitOne(10, true);
                    if (bRet == true)
                        break;
                }

            }
            finally
            {
                ws.GetEntitiesCompleted -= new GetEntitiesCompletedEventHandler(ws_GetEntitiesCompleted);
            }

            GetEntitiesCompletedEventArgs e = (GetEntitiesCompletedEventArgs)this.resultParam;

            if (e.Error != null)
            {
                strError = e.Error.Message;
                return -1;
            }

            if (e.Cancelled == true)
                strError = "�û��ж�2";
            else
                strError = e.Result.ErrorInfo;

            entityinfos = e.entityinfos;

            if (e.Result.Value == -1 && e.Result.ErrorCode == ErrorCode.NotLogin)
            {
                if (DoNotLogin(ref strError) == 1)
                    goto REDO;
            }

            this.ErrorCode = e.Result.ErrorCode;
            return e.Result.Value;
        }

        void ws_GetEntitiesCompleted(object sender, GetEntitiesCompletedEventArgs e)
        {
            this.resultParam = e;
            this.eventComplete.Set();
        }

        //

        // ����ʵ����Ϣ
        // return:
        //      -1  ����
        //      0   ����
        public long SetEntities(
            DigitalPlatform.Stop stop,
            string strBiblioRecPath,
            EntityInfo [] entityinfos,
            out EntityInfo[] errorinfos,
            out string strError)
        {
            errorinfos = null;
            strError = "";

        REDO:
            ws.SetEntitiesCompleted +=new SetEntitiesCompletedEventHandler(ws_SetEntitiesCompleted);

            try
            {
                this.eventComplete.Reset();
                ws.SetEntitiesAsync(strBiblioRecPath, entityinfos);

                while (true)
                {
                    Application.DoEvents();	// ���ý������Ȩ

                    if (stop != null)
                    {
                        if (stop.State != 0)
                        {
                            strError = "�û��ж�1";
                            return -1;
                        }
                    }

                    bool bRet = this.eventComplete.WaitOne(10, true);
                    if (bRet == true)
                        break;
                }

            }
            finally
            {
                ws.SetEntitiesCompleted -= new SetEntitiesCompletedEventHandler(ws_SetEntitiesCompleted);
            }

            SetEntitiesCompletedEventArgs e = (SetEntitiesCompletedEventArgs)this.resultParam;

            if (e.Error != null)
            {
                strError = e.Error.Message;
                return -1;
            }

            if (e.Cancelled == true)
                strError = "�û��ж�2";
            else
                strError = e.Result.ErrorInfo;

            errorinfos = e.errorinfos;

            if (e.Result.Value == -1 && e.Result.ErrorCode == ErrorCode.NotLogin)
            {
                if (DoNotLogin(ref strError) == 1)
                    goto REDO;
            }

            this.ErrorCode = e.Result.ErrorCode;
            return e.Result.Value;
        }

        void ws_SetEntitiesCompleted(object sender, SetEntitiesCompletedEventArgs e)
        {
            this.resultParam = e;
            this.eventComplete.Set();
        }

        //

        // �����Ŀ��ļ���;��
        // return:
        //      -1  ����
        //      0   ����
        public long ListBiblioDbFroms(
            DigitalPlatform.Stop stop,
            string strLang,
            out BiblioDbFromInfo[] infos,
            out string strError)
        {
            infos = null;
            strError = "";

        REDO:
            ws.ListBiblioDbFromsCompleted += new ListBiblioDbFromsCompletedEventHandler(ws_ListBiblioDbFromsCompleted);

            try
            {
                this.eventComplete.Reset();
                ws.ListBiblioDbFromsAsync(strLang);

                while (true)
                {
                    Application.DoEvents();	// ���ý������Ȩ

                    if (stop != null)
                    {
                        if (stop.State != 0)
                        {
                            strError = "�û��ж�1";
                            return -1;
                        }
                    }

                    bool bRet = this.eventComplete.WaitOne(10, true);
                    if (bRet == true)
                        break;
                }

            }
            finally
            {
                ws.ListBiblioDbFromsCompleted -= new ListBiblioDbFromsCompletedEventHandler(ws_ListBiblioDbFromsCompleted);
            }

            ListBiblioDbFromsCompletedEventArgs e = (ListBiblioDbFromsCompletedEventArgs)this.resultParam;

            if (e.Error != null)
            {
                strError = e.Error.Message;
                return -1;
            }

            if (e.Cancelled == true)
                strError = "�û��ж�2";
            else
                strError = e.Result.ErrorInfo;

            infos = e.infos;

            if (e.Result.Value == -1 && e.Result.ErrorCode == ErrorCode.NotLogin)
            {
                if (DoNotLogin(ref strError) == 1)
                    goto REDO;
            }

            this.ErrorCode = e.Result.ErrorCode;
            return e.Result.Value;
        }

        void ws_ListBiblioDbFromsCompleted(object sender, ListBiblioDbFromsCompletedEventArgs e)
        {
            this.resultParam = e;
            this.eventComplete.Set();
        }

        //
        // ������Ŀ��Ϣ
        // return:
        //      -1  ����
        //      ����    ���н������
        public long SearchBilio(
            DigitalPlatform.Stop stop,
            string strQueryWord,
            int nPerMax,
            string strFromStyle,
            string strMatchStyle,
            string strLang,
            string strResultSetName,
            out string strQueryXml,
            out string strError)
        {
            strError = "";
            strQueryXml = "";

        REDO:
            ws.SearchBiblioCompleted +=new SearchBiblioCompletedEventHandler(ws_SearchBiblioCompleted);

            try
            {
                this.eventComplete.Reset();
                ws.SearchBiblioAsync(strQueryWord,
                    nPerMax,
                    strFromStyle,
                    strMatchStyle,
                    strLang,
                    strResultSetName);

                while (true)
                {
                    Application.DoEvents();	// ���ý������Ȩ

                    if (stop != null)
                    {
                        if (stop.State != 0)
                        {
                            strError = "�û��ж�1";
                            return -1;
                        }
                    }

                    bool bRet = this.eventComplete.WaitOne(10, true);
                    if (bRet == true)
                        break;
                }

            }
            finally
            {
                ws.SearchBiblioCompleted -= new SearchBiblioCompletedEventHandler(ws_SearchBiblioCompleted);
            }

            SearchBiblioCompletedEventArgs e = (SearchBiblioCompletedEventArgs)this.resultParam;

            if (e.Error != null)
            {
                strError = e.Error.Message;
                return -1;
            }

            if (e.Cancelled == true)
                strError = "�û��ж�2";
            else
                strError = e.Result.ErrorInfo;

            strQueryXml = e.strQueryXml;

            if (e.Result.Value == -1 && e.Result.ErrorCode == ErrorCode.NotLogin)
            {
                if (DoNotLogin(ref strError) == 1)
                    goto REDO;
            }

            this.ErrorCode = e.Result.ErrorCode;
            return e.Result.Value;
        }

        void ws_SearchBiblioCompleted(object sender, SearchBiblioCompletedEventArgs e)
        {
            this.resultParam = e;
            this.eventComplete.Set();
        }

        // �����Ŀ��¼
        public long GetBiblioInfo(
            DigitalPlatform.Stop stop,
            string strBiblioRecPath,
            string strBiblioType,
            out string strBiblio,
            out string strError)
        {
            strBiblio = "";
            strError = "";

        REDO:
            ws.GetBiblioInfoCompleted += new GetBiblioInfoCompletedEventHandler(ws_GetBiblioInfoCompleted); 

            try
            {
                this.eventComplete.Reset();
                ws.GetBiblioInfoAsync(strBiblioRecPath,
                    strBiblioType);

                while (true)
                {
                    Application.DoEvents();	// ���ý������Ȩ

                    if (stop != null)
                    {
                        if (stop.State != 0)
                        {
                            strError = "�û��ж�1";
                            return -1;
                        }
                    }

                    bool bRet = this.eventComplete.WaitOne(10, true);
                    if (bRet == true)
                        break;
                }

            }
            finally
            {
                ws.GetBiblioInfoCompleted -= new GetBiblioInfoCompletedEventHandler(ws_GetBiblioInfoCompleted);
            }

            GetBiblioInfoCompletedEventArgs e = (GetBiblioInfoCompletedEventArgs)this.resultParam;

            if (e.Error != null)
            {
                strError = e.Error.Message;
                return -1;
            }

            if (e.Cancelled == true)
                strError = "�û��ж�2";
            else
                strError = e.Result.ErrorInfo;

            strBiblio = e.strBiblio;

            if (e.Result.Value == -1 && e.Result.ErrorCode == ErrorCode.NotLogin)
            {
                if (DoNotLogin(ref strError) == 1)
                    goto REDO;
            }

            this.ErrorCode = e.Result.ErrorCode;
            return e.Result.Value;
        }

        void ws_GetBiblioInfoCompleted(object sender, GetBiblioInfoCompletedEventArgs e)
        {
            this.resultParam = e;
            this.eventComplete.Set();
        }

        // 
        // ���������
        public long SearchItemDup(
            DigitalPlatform.Stop stop,
            string strBarcode,
            int nMax,
            out string [] paths,
            out string strError)
        {
            paths = null;
            strError = "";

        REDO:
            ws.SearchItemDupCompleted +=new SearchItemDupCompletedEventHandler(ws_SearchItemDupCompleted);

            try
            {
                this.eventComplete.Reset();
                ws.SearchItemDupAsync(strBarcode,
                    nMax);

                while (true)
                {
                    Application.DoEvents();	// ���ý������Ȩ

                    if (stop != null)
                    {
                        if (stop.State != 0)
                        {
                            strError = "�û��ж�1";
                            return -1;
                        }
                    }

                    bool bRet = this.eventComplete.WaitOne(10, true);
                    if (bRet == true)
                        break;
                }

            }
            finally
            {
                ws.SearchItemDupCompleted -= new SearchItemDupCompletedEventHandler(ws_SearchItemDupCompleted);
            }

            SearchItemDupCompletedEventArgs e = (SearchItemDupCompletedEventArgs)this.resultParam;

            if (e.Error != null)
            {
                strError = e.Error.Message;
                return -1;
            }

            if (e.Cancelled == true)
                strError = "�û��ж�2";
            else
                strError = e.Result.ErrorInfo;

            paths = e.paths;

            if (e.Result.Value == -1 && e.Result.ErrorCode == ErrorCode.NotLogin)
            {
                if (DoNotLogin(ref strError) == 1)
                    goto REDO;
            }

            this.ErrorCode = e.Result.ErrorCode;
            return e.Result.Value;
        }

        void ws_SearchItemDupCompleted(object sender, SearchItemDupCompletedEventArgs e)
        {
            this.resultParam = e;
            this.eventComplete.Set();
        }

        // // //

        // ���ֵ�б�
        public long GetValueTable(
            DigitalPlatform.Stop stop,
            string strTableName,
            string strDbName,
            out string[] values,
            out string strError)
        {
            values = null;
            strError = "";

            ws.GetValueTableCompleted +=new GetValueTableCompletedEventHandler(ws_GetValueTableCompleted);

            try
            {
                this.eventComplete.Reset();
                ws.GetValueTableAsync(strTableName,
                    strDbName);

                while (true)
                {
                    Application.DoEvents();	// ���ý������Ȩ

                    if (stop != null)
                    {
                        if (stop.State != 0)
                        {
                            strError = "�û��ж�1";
                            return -1;
                        }
                    }

                    bool bRet = this.eventComplete.WaitOne(10, true);
                    if (bRet == true)
                        break;
                }

            }
            finally
            {
                ws.GetValueTableCompleted -= new GetValueTableCompletedEventHandler(ws_GetValueTableCompleted);
            }

            GetValueTableCompletedEventArgs e = (GetValueTableCompletedEventArgs)this.resultParam;

            if (e.Error != null)
            {
                strError = e.Error.Message;
                return -1;
            }

            if (e.Cancelled == true)
                strError = "�û��ж�2";
            else
                strError = e.Result.ErrorInfo;

            values = e.values;

            this.ErrorCode = e.Result.ErrorCode;
            return e.Result.Value;
        }

        void ws_GetValueTableCompleted(object sender, GetValueTableCompletedEventArgs e)
        {
            this.resultParam = e;
            this.eventComplete.Set();
        }


        // ����ʱ��
        // return:
        //      -1  ����
        //      0   ����
        public long SetClock(
            DigitalPlatform.Stop stop,
            string strTime,
            out string strError)
        {
            strError = "";

            REDO:
            ws.SetClockCompleted += new SetClockCompletedEventHandler(ws_SetClockCompleted);

            try
            {
                this.eventComplete.Reset();
                ws.SetClockAsync(strTime);

                while (true)
                {
                    Application.DoEvents();	// ���ý������Ȩ

                    if (stop != null)
                    {
                        if (stop.State != 0)
                        {
                            strError = "�û��ж�1";
                            return -1;
                        }
                    }

                    bool bRet = this.eventComplete.WaitOne(10, true);
                    if (bRet == true)
                        break;
                }

            }
            finally
            {
                ws.SetClockCompleted -= new SetClockCompletedEventHandler(ws_SetClockCompleted);
            }

            SetClockCompletedEventArgs e = (SetClockCompletedEventArgs)this.resultParam;

            if (e.Error != null)
            {
                strError = e.Error.Message;
                return -1;
            }

            if (e.Cancelled == true)
                strError = "�û��ж�2";
            else
                strError = e.Result.ErrorInfo;

            if (e.Result.Value == -1 && e.Result.ErrorCode == ErrorCode.NotLogin)
            {
                if (DoNotLogin(ref strError) == 1)
                    goto REDO;
            }

            this.ErrorCode = e.Result.ErrorCode;
            return e.Result.Value;
        }

        void ws_SetClockCompleted(object sender, SetClockCompletedEventArgs e)
        {
            this.resultParam = e;
            this.eventComplete.Set();
        }

        // ���ʱ��
        public long GetClock(
            DigitalPlatform.Stop stop,
            out string strTime,
            out string strError)
        {
            strTime = "";
            strError = "";

            ws.GetClockCompleted += new GetClockCompletedEventHandler(ws_GetClockCompleted);

            try
            {
                this.eventComplete.Reset();
                ws.GetClockAsync();

                while (true)
                {
                    Application.DoEvents();	// ���ý������Ȩ

                    if (stop != null)
                    {
                        if (stop.State != 0)
                        {
                            strError = "�û��ж�1";
                            return -1;
                        }
                    }

                    bool bRet = this.eventComplete.WaitOne(10, true);
                    if (bRet == true)
                        break;
                }

            }
            finally
            {
                ws.GetClockCompleted -= new GetClockCompletedEventHandler(ws_GetClockCompleted);
            }

            GetClockCompletedEventArgs e = (GetClockCompletedEventArgs)this.resultParam;

            if (e.Error != null)
            {
                strError = e.Error.Message;
                return -1;
            }

            if (e.Cancelled == true)
                strError = "�û��ж�2";
            else
                strError = e.Result.ErrorInfo;

            strTime = e.strTime;

            this.ErrorCode = e.Result.ErrorCode;
            return e.Result.Value;
        }

        void ws_GetClockCompleted(object sender, GetClockCompletedEventArgs e)
        {
            this.resultParam = e;
            this.eventComplete.Set();
        }


        // ��֤��������
        public long VerifyReaderPassword(
            DigitalPlatform.Stop stop,
            string strReaderBarcode,
            string strReaderPassword,
            out string strError)
        {
            strError = "";

            REDO:
            ws.VerifyReaderPasswordCompleted +=new VerifyReaderPasswordCompletedEventHandler(ws_VerifyReaderPasswordCompleted);

            try
            {
                this.eventComplete.Reset();
                ws.VerifyReaderPasswordAsync(strReaderBarcode,
                    strReaderPassword);

                while (true)
                {
                    Application.DoEvents();	// ���ý������Ȩ

                    if (stop != null)
                    {
                        if (stop.State != 0)
                        {
                            strError = "�û��ж�1";
                            return -1;
                        }
                    }

                    bool bRet = this.eventComplete.WaitOne(10, true);
                    if (bRet == true)
                        break;
                }

            }
            finally
            {
                ws.VerifyReaderPasswordCompleted -= new VerifyReaderPasswordCompletedEventHandler(ws_VerifyReaderPasswordCompleted);
            }

            VerifyReaderPasswordCompletedEventArgs e = (VerifyReaderPasswordCompletedEventArgs)this.resultParam;

            if (e.Error != null)
            {
                strError = e.Error.Message;
                return -1;
            }

            if (e.Cancelled == true)
                strError = "�û��ж�2";
            else
                strError = e.Result.ErrorInfo;

            if (e.Result.Value == -1 && e.Result.ErrorCode == ErrorCode.NotLogin)
            {
                if (DoNotLogin(ref strError) == 1)
                    goto REDO;
            }

            this.ErrorCode = e.Result.ErrorCode;
            return e.Result.Value;
        }

        void ws_VerifyReaderPasswordCompleted(object sender, VerifyReaderPasswordCompletedEventArgs e)
        {
            this.resultParam = e;
            this.eventComplete.Set();
        }


        // �޸Ķ�������
        public long ChangeReaderPassword(
            DigitalPlatform.Stop stop,
            string strReaderBarcode,
            string strReaderOldPassword,
            string strReaderNewPassword,
            out string strError)
        {
            strError = "";

        REDO:
            ws.ChangeReaderPasswordCompleted += new ChangeReaderPasswordCompletedEventHandler(ws_ChangeReaderPasswordCompleted);

            try
            {
                this.eventComplete.Reset();
                ws.ChangeReaderPasswordAsync(strReaderBarcode,
                    strReaderOldPassword,
                    strReaderNewPassword);

                while (true)
                {
                    Application.DoEvents();	// ���ý������Ȩ

                    if (stop != null)
                    {
                        if (stop.State != 0)
                        {
                            strError = "�û��ж�1";
                            return -1;
                        }
                    }

                    bool bRet = this.eventComplete.WaitOne(10, true);
                    if (bRet == true)
                        break;
                }

            }
            finally
            {
                ws.ChangeReaderPasswordCompleted -= new ChangeReaderPasswordCompletedEventHandler(ws_ChangeReaderPasswordCompleted);
            }

            ChangeReaderPasswordCompletedEventArgs e = (ChangeReaderPasswordCompletedEventArgs)this.resultParam;

            if (e.Error != null)
            {
                strError = e.Error.Message;
                return -1;
            }

            if (e.Cancelled == true)
                strError = "�û��ж�2";
            else
                strError = e.Result.ErrorInfo;

            if (e.Result.Value == -1 && e.Result.ErrorCode == ErrorCode.NotLogin)
            {
                if (DoNotLogin(ref strError) == 1)
                    goto REDO;
            }

            this.ErrorCode = e.Result.ErrorCode;
            return e.Result.Value;
        }

        void ws_ChangeReaderPasswordCompleted(object sender, ChangeReaderPasswordCompletedEventArgs e)
        {
            this.resultParam = e;
            this.eventComplete.Set();
        }

        public void Abort()
        {
            // ws.Abort();
            ws.CancelAsync(null);
        }
    }

    // ��¼
    public delegate void LoginEventHandle(object sender,
    LoginEventArgs e);

    public class LoginEventArgs : EventArgs
    {
        public Channel Channel = null;

        public bool Cancel = false;
        public string ErrorInfo = "";
    }

}
