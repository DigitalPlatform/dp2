$(function(){
	
	$('.demo1').craftmap({
		image: {
			width: 1994,
			height: 1303
		}
	});
	
	$('.demo2').craftmap({
		fullscreen: true,
		image: {
			width: 1994,
			height: 1303
		}
	});
	
});
